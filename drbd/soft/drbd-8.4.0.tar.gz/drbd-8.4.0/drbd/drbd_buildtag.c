/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 28753f559ab51b549d16bcf487fe625d5919c49c"
		" build by phil@fat-tyre, 2011-07-18 15:09:28";
}
