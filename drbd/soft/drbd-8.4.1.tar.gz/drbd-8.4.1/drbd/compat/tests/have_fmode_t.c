#include <linux/types.h>

void foo()
{
	fmode_t mode;
}
