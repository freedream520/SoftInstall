#include <linux/cpumask.h>

void foo()
{
	int x = nr_cpu_ids;
}
