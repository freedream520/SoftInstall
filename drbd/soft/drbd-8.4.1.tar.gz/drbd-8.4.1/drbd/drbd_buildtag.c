/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 91b4c048c1a0e06777b5f65d312b38d47abaea80"
		" build by phil@fat-tyre, 2011-12-20 12:43:15";
}
