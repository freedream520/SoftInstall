#ifndef __WRAP_PRINTF
#define __WRAP_PRINTF

extern int wrap_printf(int indent, char *format, ...);

#endif  /* __WRAP_PRINTF */
